// 云函数：crud —— 通用集合查询 / 新增 / 删除
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()

exports.main = async (event) => {
  const action = event.action
  const payload = event.payload || {}
  const collection = payload.collection

  if (!collection) {
    return { ok: false, msg: '缺少集合名 collection' }
  }

  try {
    // 查询全部（可带 where 条件）
    if (action === 'list') {
      const res = await db.collection(collection)
        .where(payload.where || {})
        .limit(100)
        .get()
      return { ok: true, data: res.data }
    }

    // 新增
    if (action === 'add') {
      const res = await db.collection(collection).add({ data: payload.data || {} })
      return { ok: true, _id: res._id }
    }

    // 删除（按业务数字 id 字段）
    if (action === 'remove') {
      const res = await db.collection(collection)
        .where({ id: payload.id })
        .remove()
      return { ok: true, removed: res.stats.removed }
    }

    return { ok: false, msg: '未知操作：' + action }
  } catch (e) {
    return { ok: false, msg: e.message }
  }
}
