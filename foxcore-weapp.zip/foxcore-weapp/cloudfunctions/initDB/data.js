// utils/data.js —— 内置演示数据（对应文档 9 张表）
const SEED = {
  categories: [
    { id: 1, type: '节日礼品' },
    { id: 2, type: '装饰用品' },
    { id: 3, type: '食品饮料' },
    { id: 4, type: '文创周边' }
  ],
  products: [
    { id: 1, name: '圣诞限定礼盒', wholesale_cost: 128, min_price: 168, category_id: 1 },
    { id: 2, name: '新年福袋', wholesale_cost: 45, min_price: 69, category_id: 1 },
    { id: 3, name: '暖冬围巾礼盒', wholesale_cost: 58, min_price: 88, category_id: 1 },
    { id: 4, name: '圣诞装饰灯串', wholesale_cost: 22, min_price: 39, category_id: 2 },
    { id: 5, name: '迷你圣诞树', wholesale_cost: 35, min_price: 59, category_id: 2 },
    { id: 6, name: '雪花挂件套装', wholesale_cost: 12, min_price: 25, category_id: 2 },
    { id: 7, name: '热红酒香料包', wholesale_cost: 15, min_price: 29, category_id: 3 },
    { id: 8, name: '节日曲奇礼盒', wholesale_cost: 28, min_price: 49, category_id: 3 },
    { id: 9, name: 'Foxcore马克杯', wholesale_cost: 18, min_price: 35, category_id: 4 },
    { id: 10, name: '狐狸毛绒公仔', wholesale_cost: 32, min_price: 55, category_id: 4 }
  ],
  venues: [
    { id: 1, name: '长沙IFS国金中心', street: '解放西路188号', city: '长沙市', province: '湖南省', pcode: '410005', description: '核心商圈，客流密集' },
    { id: 2, name: '悦方ID MALL', street: '坡子街216号', city: '长沙市', province: '湖南省', pcode: '410002', description: '年轻客群集中，近地铁' },
    { id: 3, name: '梅溪湖新天地', street: '梅溪湖路1177号', city: '长沙市', province: '湖南省', pcode: '410205', description: '家庭客群，节庆氛围浓' }
  ],
  events: [
    { id: 1, name: '双十一返场·IFS展销会', start_date: '2026-11-10', end_date: '2026-11-20', description: '双十一余温返场促销，主打节日礼品', venue_id: 1 },
    { id: 2, name: '圣诞季预热·悦方快闪', start_date: '2026-11-15', end_date: '2026-11-25', description: '圣诞季品牌预热快闪店', venue_id: 2 },
    { id: 3, name: '圣诞季·梅溪湖主会场', start_date: '2026-12-18', end_date: '2026-12-27', description: '圣诞季主会场，筹备中', venue_id: 3 }
  ],
  booths: [
    { id: 1, location: 'A01 主展位', event_id: 1, venue_id: 1 },
    { id: 2, location: 'A02 标准展位', event_id: 1, venue_id: 1 },
    { id: 3, location: 'B01 中庭展位', event_id: 2, venue_id: 2 },
    { id: 4, location: 'B02 入口展位', event_id: 2, venue_id: 2 },
    { id: 5, location: 'C01 湖景展位', event_id: 3, venue_id: 3 },
    { id: 6, location: 'C02 长廊展位', event_id: 3, venue_id: 3 }
  ],
  salesperson: [
    { id: 1, first_name: '伟', last_name: '张', street: '芙蓉中路一段', city: '长沙市', province: '湖南省', pcode: '410005' },
    { id: 2, first_name: '娜', last_name: '李', street: '韶山北路', city: '长沙市', province: '湖南省', pcode: '410011' },
    { id: 3, first_name: '强', last_name: '王', street: '五一大道', city: '长沙市', province: '湖南省', pcode: '410001' },
    { id: 4, first_name: '静', last_name: '陈', street: '潇湘中路', city: '长沙市', province: '湖南省', pcode: '410006' }
  ],
  shifts: [
    { id: 1, date: '2026-11-10', start_time: '09:00', end_time: '15:00', salesperson_id: 1, booth_id: 1, event_id: 1 },
    { id: 2, date: '2026-11-10', start_time: '15:00', end_time: '21:00', salesperson_id: 2, booth_id: 1, event_id: 1 },
    { id: 3, date: '2026-11-10', start_time: '09:00', end_time: '15:00', salesperson_id: 3, booth_id: 2, event_id: 1 },
    { id: 4, date: '2026-11-11', start_time: '09:00', end_time: '15:00', salesperson_id: 4, booth_id: 1, event_id: 1 },
    { id: 5, date: '2026-11-11', start_time: '15:00', end_time: '21:00', salesperson_id: 1, booth_id: 2, event_id: 1 },
    { id: 6, date: '2026-11-12', start_time: '10:00', end_time: '16:00', salesperson_id: 2, booth_id: 1, event_id: 1 },
    { id: 7, date: '2026-11-13', start_time: '09:00', end_time: '15:00', salesperson_id: 3, booth_id: 1, event_id: 1 },
    { id: 8, date: '2026-11-15', start_time: '10:00', end_time: '16:00', salesperson_id: 4, booth_id: 3, event_id: 2 },
    { id: 9, date: '2026-11-15', start_time: '16:00', end_time: '22:00', salesperson_id: 1, booth_id: 3, event_id: 2 },
    { id: 10, date: '2026-11-16', start_time: '10:00', end_time: '16:00', salesperson_id: 2, booth_id: 4, event_id: 2 },
    { id: 11, date: '2026-11-16', start_time: '16:00', end_time: '22:00', salesperson_id: 3, booth_id: 3, event_id: 2 },
    { id: 12, date: '2026-11-17', start_time: '10:00', end_time: '16:00', salesperson_id: 4, booth_id: 4, event_id: 2 },
    { id: 13, date: '2026-11-17', start_time: '16:00', end_time: '22:00', salesperson_id: 1, booth_id: 3, event_id: 2 },
    { id: 14, date: '2026-11-18', start_time: '10:00', end_time: '16:00', salesperson_id: 2, booth_id: 4, event_id: 2 },
    { id: 15, date: '2026-11-18', start_time: '16:00', end_time: '22:00', salesperson_id: 3, booth_id: 3, event_id: 2 }
  ],
  sales: [
    { id: 1, sale_time: '2026-11-10 11:20', shift_id: 1, items: [{ product_id: 1, quantity: 1, final_price: 168 }, { product_id: 4, quantity: 2, final_price: 39 }] },
    { id: 2, sale_time: '2026-11-10 14:05', shift_id: 1, items: [{ product_id: 9, quantity: 2, final_price: 35 }, { product_id: 7, quantity: 1, final_price: 29 }] },
    { id: 3, sale_time: '2026-11-10 17:40', shift_id: 2, items: [{ product_id: 2, quantity: 2, final_price: 69 }] },
    { id: 4, sale_time: '2026-11-10 19:30', shift_id: 2, items: [{ product_id: 10, quantity: 1, final_price: 55 }, { product_id: 8, quantity: 1, final_price: 49 }] },
    { id: 5, sale_time: '2026-11-11 10:50', shift_id: 4, items: [{ product_id: 5, quantity: 1, final_price: 59 }, { product_id: 6, quantity: 2, final_price: 25 }] },
    { id: 6, sale_time: '2026-11-11 13:15', shift_id: 4, items: [{ product_id: 1, quantity: 1, final_price: 178 }, { product_id: 3, quantity: 1, final_price: 88 }] },
    { id: 7, sale_time: '2026-11-11 18:20', shift_id: 5, items: [{ product_id: 8, quantity: 3, final_price: 49 }] },
    { id: 8, sale_time: '2026-11-12 12:40', shift_id: 6, items: [{ product_id: 2, quantity: 1, final_price: 69 }, { product_id: 9, quantity: 1, final_price: 35 }, { product_id: 7, quantity: 2, final_price: 29 }] },
    { id: 9, sale_time: '2026-11-13 11:10', shift_id: 7, items: [{ product_id: 1, quantity: 2, final_price: 168 }] },
    { id: 10, sale_time: '2026-11-15 13:30', shift_id: 8, items: [{ product_id: 10, quantity: 2, final_price: 55 }, { product_id: 4, quantity: 1, final_price: 42 }] },
    { id: 11, sale_time: '2026-11-15 19:50', shift_id: 9, items: [{ product_id: 3, quantity: 2, final_price: 88 }, { product_id: 6, quantity: 1, final_price: 25 }] },
    { id: 12, sale_time: '2026-11-16 12:25', shift_id: 10, items: [{ product_id: 5, quantity: 2, final_price: 59 }, { product_id: 8, quantity: 1, final_price: 49 }] },
    { id: 13, sale_time: '2026-11-16 20:10', shift_id: 11, items: [{ product_id: 1, quantity: 1, final_price: 168 }, { product_id: 2, quantity: 1, final_price: 72 }] },
    { id: 14, sale_time: '2026-11-17 14:40', shift_id: 12, items: [{ product_id: 9, quantity: 3, final_price: 35 }, { product_id: 7, quantity: 1, final_price: 29 }] },
    { id: 15, sale_time: '2026-11-17 21:00', shift_id: 13, items: [{ product_id: 10, quantity: 1, final_price: 55 }, { product_id: 4, quantity: 2, final_price: 39 }, { product_id: 6, quantity: 1, final_price: 25 }] }
  ]
}

// 类别配色
const CAT_COLORS = { 1: '#E86B2C', 2: '#D9A441', 3: '#2E9E6B', 4: '#3E7CB1' }

module.exports = { SEED, CAT_COLORS }
