// 云函数：initDB —— 初始化云数据库（写入演示数据）
const cloud = require('wx-server-sdk')
const dataMod = require('./data.js')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()

exports.main = async () => {
  const SEED = dataMod.SEED
  const collections = Object.keys(SEED)
  const result = {}

  for (const name of collections) {
    // 先清空已有数据
    try {
      const existing = await db.collection(name).count()
      if (existing.total > 0) {
        // 云数据库单次 where 批量删除上限 20 条，这里演示数据量小，直接逐条删除
        const all = await db.collection(name).limit(100).get()
        for (const doc of all.data) {
          await db.collection(name).doc(doc._id).remove()
        }
      }
    } catch (e) {
      // 集合不存在时忽略，首次 add 会自动创建
    }

    // 逐条写入
    let count = 0
    for (const record of SEED[name]) {
      await db.collection(name).add({ data: record })
      count += 1
    }
    result[name] = count
  }

  return {
    ok: true,
    message: '云数据库初始化完成',
    detail: result
  }
}
