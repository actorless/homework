// app.js —— Foxcore 零售活动与销售跟踪信息系统
const store = require('./utils/store.js')

App({
  globalData: {
    // 当前角色：sales 销售人员 / mgr 活动经理 / admin 系统管理员
    role: 'sales',
    store: store
  },

  onLaunch() {
    // 云开发初始化：填入你的 AppID 后，在开发者工具中开通云开发，
    // 再把下面 env 替换为你的云环境 ID（云开发控制台可复制）。
    if (wx.cloud) {
      try {
        wx.cloud.init({
          
          traceUser: true
        })
      } catch (e) {
        // 游客模式 / 未开通云开发时忽略，前端仍可用内置演示数据预览
        console.warn('云开发未初始化，使用本地演示数据：', e)
      }
    }
    // 初始化本地数据（首次启动写入内置演示数据）
    store.init()
    this.globalData.role = store.getRole()
  }
})
