// 销售报表
const app = getApp()
const util = require('../../utils/util.js')
const dataMod = require('../../utils/data.js')

Page({
  data: {
    totalAmount: '0.00',
    totalOrders: 0,
    avgAmount: '0.00',
    eventBars: [],
    categoryBars: []
  },

  onShow() {
    const db = app.globalData.store.getDB()

    let totalAmount = 0
    const totalOrders = db.sales.length

    // 按活动汇总
    const eventMap = {}
    db.sales.forEach(function (s) {
      const amt = util.saleTotal(s)
      totalAmount += amt
      let eventId = null
      if (s.shift_id) {
        const shift = db.shifts.find(function (x) { return x.id === s.shift_id })
        if (shift) eventId = shift.event_id
      }
      const key = eventId === null ? 'none' : eventId
      eventMap[key] = (eventMap[key] || 0) + amt
    })

    const eventBars = Object.keys(eventMap).map(function (k) {
      const e = k === 'none' ? null : db.events.find(function (x) { return x.id === Number(k) })
      return { name: e ? e.name : '未归属活动', amount: eventMap[k] }
    })

    // 按类别汇总
    const catMap = {}
    db.sales.forEach(function (s) {
      s.items.forEach(function (it) {
        const p = db.products.find(function (x) { return x.id === it.product_id })
        if (p) {
          const cid = p.category_id
          catMap[cid] = (catMap[cid] || 0) + it.quantity * it.final_price
        }
      })
    })
    const categoryBars = Object.keys(catMap).map(function (k) {
      const c = db.categories.find(function (x) { return x.id === Number(k) })
      return {
        name: c ? c.type : '其他',
        color: dataMod.CAT_COLORS[k] || '#888',
        amount: catMap[k]
      }
    })

    // 计算条形百分比
    const maxEvent = Math.max.apply(null, eventBars.map(function (b) { return b.amount }).concat([1]))
    eventBars.forEach(function (b) {
      b.width = Math.round(b.amount / maxEvent * 100)
      b.text = util.money(b.amount)
    })
    const maxCat = Math.max.apply(null, categoryBars.map(function (b) { return b.amount }).concat([1]))
    categoryBars.forEach(function (b) {
      b.width = Math.round(b.amount / maxCat * 100)
      b.text = util.money(b.amount)
    })

    this.setData({
      totalAmount: util.money(totalAmount),
      totalOrders: totalOrders,
      avgAmount: util.money(totalOrders ? totalAmount / totalOrders : 0),
      eventBars: eventBars,
      categoryBars: categoryBars
    })
  }
})
