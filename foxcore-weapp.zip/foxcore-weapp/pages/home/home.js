// 工作台
const app = getApp()
const util = require('../../utils/util.js')

const ROLE_NAME = {
  sales: '销售人员',
  mgr: '活动经理',
  admin: '系统管理员'
}

Page({
  data: {
    role: 'sales',
    roleName: '',
    today: '',
    todayAmount: '0.00',
    todayOrders: 0,
    activeEvents: 0,
    menus: []
  },

  onShow() {
    const store = app.globalData.store
    const role = store.getRole()
    app.globalData.role = role
    const db = store.getDB()
    const today = util.todayStr()

    // 今日订单与金额
    let todayAmount = 0
    let todayOrders = 0
    db.sales.forEach(function (s) {
      if (s.sale_time.indexOf(today) === 0) {
        todayOrders += 1
        todayAmount += util.saleTotal(s)
      }
    })

    // 进行中活动
    const activeEvents = db.events.filter(function (e) {
      return e.start_date <= today && e.end_date >= today
    }).length

    // 快捷入口（按权限）
    const allMenus = [
      { key: 'sale', name: '销售开单', path: '/pages/sale/sale', color: '#E86B2C', isTab: true },
      { key: 'report', name: '销售报表', path: '/pages/report/report', color: '#3E7CB1', isTab: true },
      { key: 'newEvent', name: '新建活动', path: '/pages/event-detail/event-detail?new=1', color: '#2E9E6B' },
      { key: 'shift', name: '班次安排', path: '/pages/shifts/shifts', color: '#D9A441' },
      { key: 'product', name: '产品管理', path: '/pages/products/products', color: '#8A63D2' },
      { key: 'category', name: '类别管理', path: '/pages/categories/categories', color: '#C8551D' },
      { key: 'venue', name: '场地管理', path: '/pages/venues/venues', color: '#2C7A8C' },
      { key: 'staff', name: '人员管理', path: '/pages/staff/staff', color: '#5B6B7C' }
    ]
    const menus = allMenus.filter(function (m) {
      return util.canDo(role, m.key)
    }).map(function (m) {
      m.short = m.name.charAt(0)
      return m
    })

    this.setData({
      role: role,
      roleName: ROLE_NAME[role],
      today: today,
      todayAmount: util.money(todayAmount),
      todayOrders: todayOrders,
      activeEvents: activeEvents,
      menus: menus
    })
  },

  goMenu(e) {
    const item = e.currentTarget.dataset.item
    if (item.isTab) {
      wx.switchTab({ url: item.path })
    } else {
      wx.navigateTo({ url: item.path })
    }
  }
})
