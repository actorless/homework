// 产品管理
const app = getApp()
const util = require('../../utils/util.js')
const dataMod = require('../../utils/data.js')

Page({
  data: {
    productList: [],
    showForm: false,
    catNames: [],
    catIndex: 0,
    form: { name: '', wholesale_cost: '', min_price: '' }
  },

  onShow() {
    this.loadList()
  },

  loadList() {
    const db = app.globalData.store.getDB()
    const productList = db.products.map(function (p) {
      const c = db.categories.find(function (x) { return x.id === p.category_id })
      return {
        id: p.id,
        name: p.name,
        color: dataMod.CAT_COLORS[p.category_id],
        short: c ? c.type.charAt(0) : '',
        catName: c ? c.type : '',
        min: p.min_price,
        cost: p.wholesale_cost
      }
    })
    this.setData({ productList: productList })
  },

  openForm() {
    const db = app.globalData.store.getDB()
    this.setData({
      showForm: true,
      catNames: db.categories.map(function (c) { return c.type }),
      form: { name: '', wholesale_cost: '', min_price: '' },
      catIndex: 0
    })
  },

  closeForm() {
    this.setData({ showForm: false })
  },

  onInput(e) {
    this.setData({ ['form.' + e.currentTarget.dataset.field]: e.detail.value })
  },

  onCat(e) {
    this.setData({ catIndex: Number(e.detail.value) })
  },

  submit() {
    const store = app.globalData.store
    const db = store.getDB()
    const f = this.data.form
    if (!f.name) {
      wx.showToast({ title: '请填写产品名称', icon: 'none' })
      return
    }
    if (!f.min_price) {
      wx.showToast({ title: '请填写最低售价', icon: 'none' })
      return
    }
    store.addRecord('products', {
      name: f.name,
      wholesale_cost: Number(f.wholesale_cost) || 0,
      min_price: Number(f.min_price),
      category_id: db.categories[this.data.catIndex].id
    })
    this.setData({ showForm: false })
    this.loadList()
    wx.showToast({ title: '已添加', icon: 'success' })
  },

  remove(e) {
    const id = Number(e.currentTarget.dataset.id)
    const res = app.globalData.store.deleteRecord('products', id)
    if (!res.ok) {
      wx.showToast({ title: res.msg, icon: 'none' })
      return
    }
    this.loadList()
  }
})
