// 活动列表
const app = getApp()
const util = require('../../utils/util.js')

Page({
  data: {
    eventList: [],
    canCreate: false
  },

  onShow() {
    const store = app.globalData.store
    const role = store.getRole()
    const db = store.getDB()
    const today = util.todayStr()

    const eventList = db.events.map(function (e) {
      const venue = db.venues.find(function (v) { return v.id === e.venue_id })
      let status
      let tagClass
      if (e.end_date < today) {
        status = '已结束'
        tagClass = 'tag-gray'
      } else if (e.start_date > today) {
        status = '筹备中'
        tagClass = 'tag-orange'
      } else {
        status = '进行中'
        tagClass = 'tag-green'
      }
      return {
        id: e.id,
        name: e.name,
        date: e.start_date + ' 至 ' + e.end_date,
        venue: venue ? venue.name : '',
        desc: e.description,
        status: status,
        tagClass: tagClass
      }
    })

    this.setData({
      eventList: eventList,
      canCreate: util.canDo(role, 'newEvent')
    })
  },

  goDetail(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({ url: '/pages/event-detail/event-detail?id=' + id })
  },

  create() {
    wx.navigateTo({ url: '/pages/event-detail/event-detail?new=1' })
  }
})
