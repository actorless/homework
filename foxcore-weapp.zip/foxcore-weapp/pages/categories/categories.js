// 类别管理
const app = getApp()
const dataMod = require('../../utils/data.js')

Page({
  data: {
    list: [],
    showForm: false,
    typeName: ''
  },

  onShow() {
    this.loadList()
  },

  loadList() {
    const db = app.globalData.store.getDB()
    const list = db.categories.map(function (c) {
      const count = db.products.filter(function (p) { return p.category_id === c.id }).length
      return {
        id: c.id,
        type: c.type,
        short: c.type.charAt(0),
        color: dataMod.CAT_COLORS[c.id] || '#888',
        count: count
      }
    })
    this.setData({ list: list })
  },

  openForm() {
    this.setData({ showForm: true, typeName: '' })
  },
  closeForm() {
    this.setData({ showForm: false })
  },
  onInput(e) {
    this.setData({ typeName: e.detail.value })
  },

  submit() {
    if (!this.data.typeName) {
      wx.showToast({ title: '请填写类别名称', icon: 'none' })
      return
    }
    app.globalData.store.addRecord('categories', { type: this.data.typeName })
    this.setData({ showForm: false })
    this.loadList()
    wx.showToast({ title: '已添加', icon: 'success' })
  },

  remove(e) {
    const id = Number(e.currentTarget.dataset.id)
    const res = app.globalData.store.deleteRecord('categories', id)
    if (!res.ok) {
      wx.showToast({ title: res.msg, icon: 'none' })
      return
    }
    this.loadList()
  }
})
