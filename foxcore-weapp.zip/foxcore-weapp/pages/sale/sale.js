// 销售开单
const app = getApp()
const util = require('../../utils/util.js')
const dataMod = require('../../utils/data.js')

Page({
  data: {
    productList: [],
    boothNames: [],
    boothIndex: 0,
    currentBooth: null,
    noShift: false,
    shiftInfo: '',
    totalQty: 0,
    totalAmount: '0.00',
    showCheckout: false,
    checkoutItems: [],
    checkoutTotal: '0.00',
    showReceipt: false,
    receiptNo: ''
  },

  onShow() {
    const store = app.globalData.store
    const db = store.getDB()
    const today = util.todayStr()

    // 产品列表
    const productList = db.products.map(function (p) {
      const c = db.categories.find(function (x) { return x.id === p.category_id })
      return {
        id: p.id,
        name: p.name,
        price: p.min_price,
        color: dataMod.CAT_COLORS[p.category_id],
        catName: c ? c.type : '',
        short: c ? c.type.charAt(0) : '',
        qty: 0
      }
    })

    // 展位列表
    const boothNames = db.booths.map(function (b) {
      const e = db.events.find(function (x) { return x.id === b.event_id })
      return b.location + '（' + e.name + '）'
    })

    this.setData({
      productList: productList,
      boothNames: boothNames
    })
    this.refreshShift()
  },

  // 数量加减
  changeQty(e) {
    const ds = e.currentTarget.dataset
    const idx = ds.index
    const step = Number(ds.step)
    const key = 'productList[' + idx + '].qty'
    let qty = this.data.productList[idx].qty + step
    if (qty < 0) qty = 0
    this.setData({ [key]: qty })
    this.refreshTotal()
  },

  // 切换展位
  onBoothChange(e) {
    this.setData({ boothIndex: Number(e.detail.value) })
    this.refreshShift()
  },

  // 根据当前展位找今日班次
  refreshShift() {
    const db = app.globalData.store.getDB()
    const booth = db.booths[this.data.boothIndex]
    const today = util.todayStr()
    const shift = db.shifts.find(function (s) {
      return s.booth_id === booth.id && s.date === today
    })
    let shiftInfo = ''
    if (shift) {
      const sp = db.salesperson.find(function (p) { return p.id === shift.salesperson_id })
      shiftInfo = '今日班次：' + util.personName(sp) + ' ' + shift.start_time + '-' + shift.end_time
    }
    this.setData({
      currentBooth: booth,
      noShift: !shift,
      shiftInfo: shiftInfo,
      _shift: shift
    })
  },

  refreshTotal() {
    let qty = 0
    let amount = 0
    this.data.productList.forEach(function (p) {
      qty += p.qty
      amount += p.qty * p.price
    })
    this.setData({
      totalQty: qty,
      totalAmount: util.money(amount)
    })
  },

  // 打开结算确认
  openCheckout() {
    if (this.data.totalQty === 0) {
      wx.showToast({ title: '请先选择商品', icon: 'none' })
      return
    }
    const items = this.data.productList.filter(function (p) { return p.qty > 0 })
      .map(function (p) {
        return {
          name: p.name,
          qty: p.qty,
          price: util.money(p.price),
          subtotal: util.money(p.qty * p.price)
        }
      })
    this.setData({
      showCheckout: true,
      checkoutItems: items,
      checkoutTotal: this.data.totalAmount
    })
  },

  closeCheckout() {
    this.setData({ showCheckout: false })
  },

  // 确认提交
  confirmSale() {
    const store = app.globalData.store
    const cart = {}
    this.data.productList.forEach(function (p) {
      if (p.qty > 0) {
        cart[p.id] = { quantity: p.qty, final_price: p.price }
      }
    })
    const shift = this.data._shift
    const sale = store.addSale(cart, shift ? shift.id : null)

    // 重置数量
    const reset = this.data.productList.map(function (p) {
      p.qty = 0
      return p
    })
    this.setData({
      productList: reset,
      showCheckout: false,
      showReceipt: true,
      receiptNo: 'FX' + String(sale.id).padStart(6, '0'),
      totalQty: 0,
      totalAmount: '0.00'
    })
  },

  closeReceipt() {
    this.setData({ showReceipt: false })
  }
})
