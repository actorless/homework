// 我的
const app = getApp()

const ROLE_NAME = {
  sales: '销售人员',
  mgr: '活动经理',
  admin: '系统管理员'
}

Page({
  data: {
    role: 'sales',
    roleName: '',
    roles: [
      { value: 'sales', name: '销售人员' },
      { value: 'mgr', name: '活动经理' },
      { value: 'admin', name: '系统管理员' }
    ],
    entries: [
      { name: '销售订单', path: '/pages/orders/orders' },
      { name: '班次安排', path: '/pages/shifts/shifts' },
      { name: '产品管理', path: '/pages/products/products' },
      { name: '类别管理', path: '/pages/categories/categories' },
      { name: '场地管理', path: '/pages/venues/venues' },
      { name: '人员管理', path: '/pages/staff/staff' }
    ]
  },

  onShow() {
    const role = app.globalData.store.getRole()
    this.setData({ role: role, roleName: ROLE_NAME[role] })
  },

  switchRole(e) {
    const value = e.currentTarget.dataset.value
    app.globalData.store.setRole(value)
    app.globalData.role = value
    this.setData({ role: value, roleName: ROLE_NAME[value] })
    wx.showToast({ title: '已切换为' + ROLE_NAME[value], icon: 'none' })
  },

  goEntry(e) {
    wx.navigateTo({ url: e.currentTarget.dataset.path })
  },

  resetData() {
    wx.showModal({
      title: '恢复演示数据',
      content: '将清空当前所有改动并恢复为初始演示数据，确认继续？',
      success: function (res) {
        if (res.confirm) {
          app.globalData.store.resetData()
          wx.showToast({ title: '已恢复演示数据', icon: 'success' })
        }
      }
    })
  }
})
