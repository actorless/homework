// 场地管理
const app = getApp()

Page({
  data: {
    list: [],
    showForm: false,
    form: { name: '', city: '', street: '', description: '' }
  },

  onShow() {
    this.loadList()
  },

  loadList() {
    const db = app.globalData.store.getDB()
    const list = db.venues.map(function (v) {
      const count = db.events.filter(function (e) { return e.venue_id === v.id }).length
      return {
        id: v.id,
        name: v.name,
        short: v.name.charAt(0),
        addr: v.province + v.city + v.street,
        desc: v.description,
        count: count
      }
    })
    this.setData({ list: list })
  },

  openForm() {
    this.setData({
      showForm: true,
      form: { name: '', city: '', street: '', description: '' }
    })
  },
  closeForm() {
    this.setData({ showForm: false })
  },
  onInput(e) {
    this.setData({ ['form.' + e.currentTarget.dataset.field]: e.detail.value })
  },

  submit() {
    const f = this.data.form
    if (!f.name) {
      wx.showToast({ title: '请填写场地名称', icon: 'none' })
      return
    }
    app.globalData.store.addRecord('venues', {
      name: f.name,
      city: f.city,
      street: f.street,
      province: '湖南省',
      pcode: '',
      description: f.description
    })
    this.setData({ showForm: false })
    this.loadList()
    wx.showToast({ title: '已添加', icon: 'success' })
  },

  remove(e) {
    const id = Number(e.currentTarget.dataset.id)
    const res = app.globalData.store.deleteRecord('venues', id)
    if (!res.ok) {
      wx.showToast({ title: res.msg, icon: 'none' })
      return
    }
    this.loadList()
  }
})
