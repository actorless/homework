// 班次管理
const app = getApp()
const util = require('../../utils/util.js')

Page({
  data: {
    shiftList: [],
    showForm: false,
    eventNames: [],
    boothNames: [],
    spNames: [],
    eventIndex: 0,
    boothIndex: 0,
    spIndex: 0,
    formDate: '',
    startTime: '09:00',
    endTime: '15:00'
  },

  onShow() {
    this.loadList()
  },

  loadList() {
    const db = app.globalData.store.getDB()
    const shiftList = db.shifts.map(function (s) {
      const sp = db.salesperson.find(function (p) { return p.id === s.salesperson_id })
      const b = db.booths.find(function (x) { return x.id === s.booth_id })
      return {
        id: s.id,
        date: s.date,
        person: sp ? util.personName(sp) : '',
        short: sp ? util.personName(sp).charAt(0) : '',
        booth: b ? b.location : '',
        time: s.start_time + '-' + s.end_time
      }
    }).sort(function (a, b) {
      return (a.date + a.time) < (b.date + b.time) ? -1 : 1
    })
    this.setData({ shiftList: shiftList })
  },

  openForm() {
    const db = app.globalData.store.getDB()
    this.setData({
      showForm: true,
      formDate: util.todayStr(),
      eventNames: db.events.map(function (e) { return e.name }),
      boothNames: db.booths.map(function (b) { return b.location }),
      spNames: db.salesperson.map(function (p) { return util.personName(p) })
    })
  },

  closeForm() {
    this.setData({ showForm: false })
  },

  onDate(e) {
    this.setData({ formDate: e.detail.value })
  },
  onStart(e) {
    this.setData({ startTime: e.detail.value })
  },
  onEnd(e) {
    this.setData({ endTime: e.detail.value })
  },
  onEvent(e) {
    this.setData({ eventIndex: Number(e.detail.value) })
  },
  onBooth(e) {
    this.setData({ boothIndex: Number(e.detail.value) })
  },
  onSp(e) {
    this.setData({ spIndex: Number(e.detail.value) })
  },

  submit() {
    const store = app.globalData.store
    const db = store.getDB()
    const event = db.events[this.data.eventIndex]
    const booth = db.booths[this.data.boothIndex]
    const sp = db.salesperson[this.data.spIndex]

    const res = store.addShift({
      date: this.data.formDate,
      start_time: this.data.startTime,
      end_time: this.data.endTime,
      event_id: event.id,
      booth_id: booth.id,
      salesperson_id: sp.id
    })

    if (!res.ok) {
      wx.showToast({ title: res.msg, icon: 'none' })
      return
    }
    wx.showToast({ title: res.msg, icon: 'success' })
    this.setData({ showForm: false })
    this.loadList()
  }
})
