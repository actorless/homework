// 活动详情 / 新建
const app = getApp()
const util = require('../../utils/util.js')

Page({
  data: {
    isNew: false,
    // 查看态
    detail: null,
    // 新建表单
    form: {
      name: '',
      start_date: '',
      end_date: '',
      description: '',
      venue_id: null
    },
    venueNames: [],
    venueIndex: 0
  },

  onLoad(query) {
    const store = app.globalData.store
    const db = store.getDB()

    if (query.new) {
      wx.setNavigationBarTitle({ title: '新建活动' })
      this.setData({
        isNew: true,
        venueNames: db.venues.map(function (v) { return v.name }),
        'form.start_date': util.todayStr(),
        'form.end_date': util.todayStr()
      })
      return
    }

    const id = Number(query.id)
    const e = db.events.find(function (x) { return x.id === id })
    const venue = db.venues.find(function (v) { return v.id === e.venue_id })
    const booths = db.booths.filter(function (b) { return b.event_id === id })
    const shifts = db.shifts.filter(function (s) { return s.event_id === id })

    // 活动销售额
    let amount = 0
    const shiftIds = shifts.map(function (s) { return s.id })
    db.sales.forEach(function (s) {
      if (s.shift_id && shiftIds.indexOf(s.shift_id) !== -1) {
        amount += util.saleTotal(s)
      }
    })

    const boothList = booths.map(function (b) {
      const spCount = db.shifts.filter(function (s) { return s.booth_id === b.id }).length
      return { id: b.id, location: b.location, shiftCount: spCount }
    })

    wx.setNavigationBarTitle({ title: e.name })
    this.setData({
      detail: {
        id: e.id,
        name: e.name,
        date: e.start_date + ' 至 ' + e.end_date,
        venue: venue ? venue.name : '',
        desc: e.description,
        boothCount: booths.length,
        shiftCount: shifts.length,
        amount: util.money(amount),
        booths: boothList
      }
    })
  },

  onInput(e) {
    const field = e.currentTarget.dataset.field
    this.setData({ ['form.' + field]: e.detail.value })
  },

  onVenue(e) {
    const idx = Number(e.detail.value)
    const db = app.globalData.store.getDB()
    this.setData({
      venueIndex: idx,
      'form.venue_id': db.venues[idx].id
    })
  },

  onStartDate(e) {
    this.setData({ 'form.start_date': e.detail.value })
  },

  onEndDate(e) {
    this.setData({ 'form.end_date': e.detail.value })
  },

  submit() {
    const store = app.globalData.store
    const f = this.data.form
    if (!f.name) {
      wx.showToast({ title: '请填写活动名称', icon: 'none' })
      return
    }
    if (!f.venue_id) {
      wx.showToast({ title: '请选择场地', icon: 'none' })
      return
    }
    if (f.end_date < f.start_date) {
      wx.showToast({ title: '结束日期不能早于开始日期', icon: 'none' })
      return
    }
    store.addRecord('events', {
      name: f.name,
      start_date: f.start_date,
      end_date: f.end_date,
      description: f.description,
      venue_id: f.venue_id
    })
    wx.showToast({ title: '活动已创建', icon: 'success' })
    setTimeout(function () { wx.navigateBack() }, 800)
  }
})
