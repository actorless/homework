// 人员管理
const app = getApp()

Page({
  data: {
    list: [],
    showForm: false,
    form: { last_name: '', first_name: '', city: '' }
  },

  onShow() {
    this.loadList()
  },

  loadList() {
    const db = app.globalData.store.getDB()
    const list = db.salesperson.map(function (p) {
      const count = db.shifts.filter(function (s) { return s.salesperson_id === p.id }).length
      return {
        id: p.id,
        name: p.last_name + p.first_name,
        short: p.last_name,
        city: p.city,
        count: count
      }
    })
    this.setData({ list: list })
  },

  openForm() {
    this.setData({
      showForm: true,
      form: { last_name: '', first_name: '', city: '' }
    })
  },
  closeForm() {
    this.setData({ showForm: false })
  },
  onInput(e) {
    this.setData({ ['form.' + e.currentTarget.dataset.field]: e.detail.value })
  },

  submit() {
    const f = this.data.form
    if (!f.last_name || !f.first_name) {
      wx.showToast({ title: '请填写姓名', icon: 'none' })
      return
    }
    app.globalData.store.addRecord('salesperson', {
      last_name: f.last_name,
      first_name: f.first_name,
      city: f.city,
      province: '湖南省',
      street: '',
      pcode: ''
    })
    this.setData({ showForm: false })
    this.loadList()
    wx.showToast({ title: '已添加', icon: 'success' })
  },

  remove(e) {
    const id = Number(e.currentTarget.dataset.id)
    const res = app.globalData.store.deleteRecord('salesperson', id)
    if (!res.ok) {
      wx.showToast({ title: res.msg, icon: 'none' })
      return
    }
    this.loadList()
  }
})
