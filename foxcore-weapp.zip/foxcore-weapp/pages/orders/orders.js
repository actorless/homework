// 销售订单
const app = getApp()
const util = require('../../utils/util.js')

Page({
  data: {
    orderList: []
  },

  onShow() {
    const db = app.globalData.store.getDB()

    const orderList = db.sales.map(function (s) {
      let eventName = '未归属'
      if (s.shift_id) {
        const shift = db.shifts.find(function (x) { return x.id === s.shift_id })
        if (shift) {
          const e = db.events.find(function (x) { return x.id === shift.event_id })
          if (e) eventName = e.name
        }
      }
      let qty = 0
      const items = s.items.map(function (it) {
        const p = db.products.find(function (x) { return x.id === it.product_id })
        qty += it.quantity
        return {
          name: p ? p.name : '商品#' + it.product_id,
          quantity: it.quantity,
          price: util.money(it.final_price),
          subtotal: util.money(it.quantity * it.final_price)
        }
      })
      return {
        id: s.id,
        no: 'FX' + String(s.id).padStart(6, '0'),
        time: s.sale_time,
        eventName: eventName,
        qty: qty,
        total: util.money(util.saleTotal(s)),
        items: items,
        open: false
      }
    }).sort(function (a, b) {
      return a.time < b.time ? 1 : -1
    })

    this.setData({ orderList: orderList })
  },

  toggle(e) {
    const idx = e.currentTarget.dataset.index
    this.setData({ ['orderList[' + idx + '].open']: !this.data.orderList[idx].open })
  }
})
