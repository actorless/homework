// utils/util.js —— 通用工具函数
function pad2(n) {
  return n < 10 ? '0' + n : '' + n
}

function money(n) {
  return Number(n).toLocaleString('zh-CN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })
}

function todayStr() {
  const d = new Date()
  return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate())
}

function personName(sp) {
  return sp.last_name + sp.first_name
}

function timeToMin(t) {
  const p = t.split(':')
  return Number(p[0]) * 60 + Number(p[1])
}

// 角色权限映射
function canDo(role, act) {
  const map = {
    sale: ['sales', 'mgr', 'admin'],
    report: ['sales', 'mgr', 'admin'],
    newEvent: ['mgr', 'admin'],
    shift: ['mgr', 'admin'],
    product: ['admin'],
    category: ['admin'],
    venue: ['admin', 'mgr'],
    staff: ['admin']
  }
  return (map[act] || []).indexOf(role) !== -1
}

// 单张销售单总金额
function saleTotal(sale) {
  return sale.items.reduce(function (sum, it) {
    return sum + it.quantity * it.final_price
  }, 0)
}

function deepClone(obj) {
  return JSON.parse(JSON.stringify(obj))
}

module.exports = {
  pad2: pad2,
  money: money,
  todayStr: todayStr,
  personName: personName,
  timeToMin: timeToMin,
  canDo: canDo,
  saleTotal: saleTotal,
  deepClone: deepClone
}
