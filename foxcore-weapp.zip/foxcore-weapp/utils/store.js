// utils/store.js —— 数据管理（本地持久化 + 云函数预留）
const dataMod = require('./data.js')
const util = require('./util.js')

const DB_KEY = 'foxcore_db_v1'
const ROLE_KEY = 'foxcore_role_v1'
const COLLECTIONS = ['categories', 'products', 'venues', 'events', 'booths',
  'salesperson', 'shifts', 'sales']

// 切换为 true 后，读写将走云函数（需先开通云开发并部署 crud）。
// 当前为 false，使用本地演示数据，保证导入即可预览。
const USE_CLOUD = false

let db = null

function init() {
  const cached = wx.getStorageSync(DB_KEY)
  if (cached && cached.sales) {
    db = cached
  } else {
    db = util.deepClone(dataMod.SEED)
    saveDB()
  }
}

function getDB() {
  return db
}

function saveDB() {
  wx.setStorageSync(DB_KEY, db)
}

function resetData() {
  db = util.deepClone(dataMod.SEED)
  saveDB()
}

function getRole() {
  return wx.getStorageSync(ROLE_KEY) || 'sales'
}

function setRole(role) {
  wx.setStorageSync(ROLE_KEY, role)
}

function nextId(list) {
  return list.reduce(function (m, x) {
    return Math.max(m, x.id)
  }, 0) + 1
}

/* ===== 班次：新增（含时间冲突校验） ===== */
function addShift(o) {
  if (!o.event_id || !o.booth_id) return { ok: false, msg: '请选择活动与展位' }
  if (!o.date) return { ok: false, msg: '请选择日期' }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(o.date)) return { ok: false, msg: '日期格式无效，请重新选择' }
  if (!o.start_time || !o.end_time) return { ok: false, msg: '请设置起止时间' }
  if (!/^\d{2}:\d{2}$/.test(o.start_time) || !/^\d{2}:\d{2}$/.test(o.end_time)) {
    return { ok: false, msg: '时间格式无效，请重新选择' }
  }
  const s1 = util.timeToMin(o.start_time)
  const s2 = util.timeToMin(o.end_time)
  if (s1 >= s2) return { ok: false, msg: '开始时间须早于结束时间' }
  if (!o.salesperson_id) return { ok: false, msg: '请选择销售人员' }

  const conflict = db.shifts.find(function (x) {
    return x.salesperson_id === Number(o.salesperson_id) &&
      x.date === o.date &&
      util.timeToMin(x.start_time) < s2 &&
      util.timeToMin(x.end_time) > s1
  })
  if (conflict) return { ok: false, msg: '该人员此时段已有班次，时间冲突' }

  db.shifts.push({
    id: nextId(db.shifts),
    date: o.date,
    start_time: o.start_time,
    end_time: o.end_time,
    salesperson_id: Number(o.salesperson_id),
    booth_id: Number(o.booth_id),
    event_id: Number(o.event_id)
  })
  saveDB()
  return { ok: true, msg: '班次已保存' }
}

/* ===== 销售单：新增 ===== */
function addSale(cart, shiftId) {
  const items = Object.keys(cart).map(function (pid) {
    const c = cart[pid]
    return {
      product_id: Number(pid),
      quantity: c.quantity,
      final_price: c.final_price
    }
  })
  const now = new Date()
  const saleTime = util.todayStr() + ' ' +
    util.pad2(now.getHours()) + ':' + util.pad2(now.getMinutes())
  const sale = {
    id: nextId(db.sales),
    sale_time: saleTime,
    shift_id: shiftId || null,
    items: items
  }
  db.sales.push(sale)
  saveDB()
  return sale
}

/* ===== 通用新增 / 删除（基础数据） ===== */
function addRecord(collection, record) {
  record.id = nextId(db[collection])
  db[collection].push(record)
  saveDB()
  return record
}

function deleteRecord(collection, id) {
  // 引用检查，避免产生孤儿数据
  if (collection === 'products') {
    const used = db.sales.some(function (s) {
      return s.items.some(function (it) { return it.product_id === id })
    })
    if (used) return { ok: false, msg: '该产品已被销售明细引用，无法删除' }
  }
  if (collection === 'categories') {
    if (db.products.some(function (p) { return p.category_id === id })) {
      return { ok: false, msg: '该类别下仍有产品，无法删除' }
    }
  }
  if (collection === 'venues') {
    if (db.events.some(function (e) { return e.venue_id === id })) {
      return { ok: false, msg: '该场地已关联活动，无法删除' }
    }
  }
  if (collection === 'salesperson') {
    if (db.shifts.some(function (sh) { return sh.salesperson_id === id })) {
      return { ok: false, msg: '该人员已有班次，无法删除' }
    }
  }
  db[collection] = db[collection].filter(function (x) { return x.id !== id })
  saveDB()
  return { ok: true, msg: '已删除' }
}

/* ===== 云函数调用（USE_CLOUD 开启后使用） ===== */
function cloudCall(action, payload) {
  return wx.cloud.callFunction({
    name: 'crud',
    data: { action: action, payload: payload }
  })
}

module.exports = {
  USE_CLOUD: USE_CLOUD,
  COLLECTIONS: COLLECTIONS,
  init: init,
  getDB: getDB,
  saveDB: saveDB,
  resetData: resetData,
  getRole: getRole,
  setRole: setRole,
  addShift: addShift,
  addSale: addSale,
  addRecord: addRecord,
  deleteRecord: deleteRecord,
  cloudCall: cloudCall
}
